averageData.py is the baseline attack. 
bnetwork.py is the correlation matrix code for Bayesian network construction. 
getUsers.py is the data processing code. 
KmeansAttack.py implements our multivariate Gaussian example generation. 